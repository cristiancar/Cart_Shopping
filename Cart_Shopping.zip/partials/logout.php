<?php
session_start();
session_destroy();

header('Location: /Melker_Hedengren_crud/index.php');

?>